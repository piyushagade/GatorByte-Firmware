#include "../platform.h"

#if GB_PLATFORM_IS_CHMD_BIT

    /* 
        ! Gatorbyte library
        Import the GatorByte library (GBL).
    */
    #include "GB.h"


    /* 
        ! Gatorbyte core instance
        This is a virtual twin of the GatorByte datalogger. All the peripherals and sensors 
        will be "in" this virtual twin. Pass this object to the peripherals/sensors as the 
        first parameter.
    */
    GB gb = GB();

    /* 
        ! Peripherals and sensors (devices) instances
        Include the instances for the devices that your GatorByte physically 
        has. Include the microcontroller, a communication protocol, and the other devices. 
    */

    // Microcontroller and communications
    GB_NB1500 mcu(gb);

    GB_MQTT mqtt(gb);
    GB_HTTP http(gb);
    GB_74HC595 ioe(gb);

    // Peripherals and devices
    GB_RGB rgb(gb);
    GB_PWRMTR pwr(gb);
    GB_AT24 mem(gb);
    GB_SD sd(gb);
    GB_DS3231 rtc(gb);
    GB_BOOSTER booster(gb);
    GB_AT_09 bl(gb);
    GB_BUZZER buzzer(gb);

    GB_AHT10 aht(gb);
    GB_DESKTOP gdc(gb);
    GB_SNTL sntl(gb);

    GB_RELAY vst(gb);
    GB_EADC eadc(gb);
    GB_TPBCK rain(gb);

    GB_PIPER breathpiper(gb);
    GB_PIPER wlevpiper(gb);
    GB_PIPER resetvariablespiper(gb);
    GB_PIPER uploaderpiper(gb);
    GB_PIPER controlvariablespiper(gb);
    GB_PIPER antifreezepiper(gb);
    GB_PIPER fivedayantifreezepiper(gb);
    GB_PIPER pingpiper(gb);
    GB_PIPER statepiper(gb);
    
    String STATE = "IDLE";
    int RAINID = 0;
    int HOURID = -1;
    int WLEV = 0;
    int TIMETRACKER = 0;
    int TIME = 0;
    int RAININT = 0;
    bool REBOOT_FLAG = false;
    bool RESET_VARIABLES_FLAG = false;

    /*
        Time trackers
    */
    int CV_UPLOAD_INTERVAL = 15 * 60 * 1000;
    int STATE_UPLOAD_INTERVAL = 3 * 60 * 1000;
    int QUEUE_UPLOAD_INTERVAL = 10 * 60 * 1000;
    int QUEUE_LAST_UPLOAD_AT = 0;
    int WLEV_SAMPLING_INTERVAL = 10 * 60 * 1000;
    int WLEV_LAST_SAMPLE_AT = 0;
    String FRUIT = "Banana";
    int32_t INITSECONDS = 0;

    /*
        Timestamps
    */
    int FIRST_TIP_AT_TIMESTAMP = 0;
    int LAST_TIP_AT_TIMESTAMP = 0;
    int TREATMENT_STARTED_AT_TIMESTAMP = 0;

    /*
        Counts
    */
    int CUMULATIVE_TIP_COUNT = 0;
    int RAIN_INCHES = 0;
    
    /*
        Thresholds
    */
    int END_TIP_CONT_THRESHOLD = 3;
    int MIN_TIP_CONT_THRESHOLD = 10;
    
    /*
        Timeouts
    */
    int INTER_TIP_TIMEOUT = 6 * 60 * 60;
    int HOMOGENIZATION_DELAY = 6 * 60 * 60 * 1000;
    int INTER_SAMPLE_DURATION = 3 * 60 * 60 * 1000;
    int ANTIFREEZE_REBOOT_DELAY = 5 * 86400 * 1000;
    
    /*
        Intervals
    */
    int BREATH_INTERVAL = 60 * 1000;
    int REMOTE_RESET_CHECK_INTERVAL = 1 * 60 * 1000;
    int ANTIFREEZE_CHECK_INTERVAL = 15 * 60 * 1000;
    int SERVER_PING_INTERVAL = 30 * 60 * 1000;

    /*
        Miscellaneous
    */
    int MEMLOC_RAINID = 32;
    int MEMLOC_LASTSTATE = 33;
    int MEMLOC_CUMMTIPCOUNT = 34;
    int MEMLOC_TRTSTRTTMSTP = 35;
    int MEMLOC_LASTTIPTMSTP = 36;
    int MEMLOC_RAININTENSITY = 37;

    void send_state () {

        if (!STATE.contains("new-trt-begin")) return;

        JSONary state;
        state
            .set("STATE", mem.get(MEMLOC_LASTSTATE))
            .set("WLEV", mem.get(WLEV))
            .set("TIPS", mem.get(MEMLOC_CUMMTIPCOUNT))
            .set("TIPTMSTP", mem.get(MEMLOC_LASTTIPTMSTP))
            .set("TRTTMSTP", mem.get(MEMLOC_TRTSTRTTMSTP))
            .set("HOURID", HOURID)
            .set("RAINID", RAINID);

        gb.log("Uploading state");
        gb.log(state.get());
        
        mqtt.publish("state/report", state.get());
    }

    void send_control_variables () {
        
        mqtt.publish("control/report", gb.CONTROLVARIABLES.get());
    }


    /* 
        ! Set control variables
        This callback is executed when the control variables file is successfully read
    */

    void set_control_variables(JSONary data) {

        QUEUE_UPLOAD_INTERVAL = data.parseInt("CV_UPLOAD_INTERVAL");
        WLEV_SAMPLING_INTERVAL = data.parseInt("WLEV_SAMPLING_INTERVAL");
        END_TIP_CONT_THRESHOLD = data.parseInt("END_TIP_CONT_THRESHOLD");
        MIN_TIP_CONT_THRESHOLD = data.parseInt("MIN_TIP_CONT_THRESHOLD");
        REBOOT_FLAG = data.parseBoolean("REBOOT_FLAG");
        RESET_VARIABLES_FLAG = data.parseBoolean("RESET_VARIABLES_FLAG");
        INTER_TIP_TIMEOUT = data.parseInt("INTER_TIP_TIMEOUT");
        HOMOGENIZATION_DELAY = data.parseInt("HOMOGENIZATION_DELAY");
        INTER_SAMPLE_DURATION = data.parseInt("INTER_SAMPLE_DURATION");
        CV_UPLOAD_INTERVAL = data.parseInt("CV_UPLOAD_INTERVAL");
        ANTIFREEZE_REBOOT_DELAY = data.parseInt("ANTIFREEZE_REBOOT_DELAY");

        gb.log("Updating runtime variables -> Done");

        // Send the fresh list of control variables
        mqtt.publish("control/report", gb.CONTROLVARIABLES.get());
    }
    
    void resetvariables () {

        gb.br().log("Request to reset variables -> Processed");
        gb.br();

        mem.write(MEMLOC_LASTSTATE, "");
        mem.write(MEMLOC_CUMMTIPCOUNT, "0");
        mem.write(MEMLOC_RAINID, "0");
        mem.write(MEMLOC_TRTSTRTTMSTP, "0");
        mem.write(MEMLOC_RAININTENSITY, "0");

        STATE = "dry";
        CUMULATIVE_TIP_COUNT = 0;
        RAINID = 0;

        // String filename = "/readings/" + (gb.DEVICE_ID.length() > 0 ? gb.DEVICE_ID + "_" : "") + "readings.csv";
        // sd.rm(filename);

        // Reset flag
        RESET_VARIABLES_FLAG = 0;
        sd.updatecontrolbool("RESET_VARIABLES_FLAG", RESET_VARIABLES_FLAG, set_control_variables);

        buzzer.play("-----");
    }

    void devicereboot () {

        gb.log("Rebooting device -> Done");

        // Reset flag
        REBOOT_FLAG = false;
        sd.updatecontrolbool("REBOOT_FLAG", REBOOT_FLAG, set_control_variables);

        buzzer.play(".....");

        sntl.reboot();
    }

    void parse(String str){

        // Update the variables in SD card and in runtime memory
        sd.updatecontrol(str, set_control_variables);
        
        mqtt.publish("log/message", "Control variables updated.");
        // send_control_variables();

        // if (RESET_VARIABLES_FLAG) {
        //     resetvariables();
        //     RESET_VARIABLES_FLAG = 0;
        // }
        // if (REBOOT_FLAG) {
            // devicereboot();
        //     REBOOT_FLAG = 0;
        // }
    }

    /* 
        ! Procedure to handle incoming MQTT messages
        It is mandatory to define this function if GB_MQTT library is instantiated above
    */

    void mqtt_message_handler(String topic, String message) {

        gb.br().br().log("Incoming topic: " + topic);
        gb.log("Incoming message: " + message);
        gb.br().br();

        // If broker sends an acknowledgement
        if (topic == "gatorbyte/ack" && message == "success") {
            mqtt.ACK_RECEIVED = true;
            return;
        }

        parse(message);

        // String targetdevice = topic.substring(0, topic.indexOf("::"));
        // if (targetdevice != gb.DEVICE_ID) return;

        // topic = topic.substring(topic.indexOf("::") + 1, topic.length());

        // if (topic == "gb-lab/test") {
        //     mqtt.publish("gatorbyte::gb-lab::response", "message");
        // }

    }

    /* 
        ! Subscribe to topics
        This callback is executed the GB connects to the MQTT broker
    */

    void mqtt_on_connect() {
        mqtt.subscribe("gb-lab/test");
        mqtt.subscribe("ping");
        mqtt.subscribe("control/update");
        mqtt.subscribe("gatorbyte/ack");
    }

    /* 
        ! Actions to perform before going to sleep
        You can turn specific components on/off. By default all components are turned off before
        entering power-saving mode (sleep)
    */

    void on_sleep() {
        gb.br().log("Performing user-defined pre-sleep tasks");

        // mqtt.disconnect();
        mcu.disconnect("cellular");

        // Disable timer
        // mcu.stopbreathtimer();

        delay(1000);
    }

    /* 
        ! Actions to perform after the microcontroller wakes up
        You can turn specific components on/off.
    */

    void on_wakeup() {
        
        rgb.on("magenta");
        delay(5000);

        gb.log("The device is now awake.");
        gdc.send("highlight-yellow", "Device awake");
    }

    /*
        ! Set date and time for files in the SD card
    */
    void setsddatetime(uint16_t* date, uint16_t* time) {

        // Get datetime object
        DateTime now = rtc.now();

        // return date using FAT_DATE macro to format fields
        *date = FAT_DATE(now.year(), now.month(), now.day());

        // return time using FAT_TIME macro to format fields
        *time = FAT_TIME(now.hour(), now.minute(), now.second());
    }

    // Start antifreeze sentinence monitor    
    void antifreeze_monitor () {
        sntl.disable().interval("sentinence", 30 * 60).enable();
    }

    /*
        ! Send data to server
        Send the queue data first.
        Then send the current data to the server.
    */
    void send_queue_files_to_server() {

        if (sd.getqueuecount() > 0) {

            gb.br().log("Found " + String(sd.getqueuecount()) + " queue files.");

            sntl.shield(45, [] {
                
                //! Connect to network
                mcu.connect("cellular");
                
                sntl.kick();

                //! Connect to MQTT servver
                mqtt.connect("pi", "abe-gb-mqtt");
                
            });

            gb.log("MQTT connection attempted");
            
            //! Publish first ten queued-data with MQTT
            sntl.shield(60, [] {

                if (CONNECTED_TO_MQTT_BROKER) {
                    int counter = 10;
                    
                    while (!sd.isqueueempty() && counter-- > 0) {

                        String queuefilename = sd.getfirstqueuefilename();

                        gb.log("Sending queue file: " + queuefilename);

                        // Attempt publishing queue-data
                        if (mqtt.publish("data/set", sd.readqueuefile(queuefilename))) {

                            // Remove queue file
                            sd.removequeuefile(queuefilename);
                        }

                        else {
                            gb.log("Queue file not deleted.");
                        }
                    }
                }
            });

            // Turn on antifreeze monitor
            antifreeze_monitor();

        }
        else {
            gb.br().log("Found " + String(sd.getqueuecount()) + " queue files. Skipping upload.");
        }
    }

    void write_data_to_sd_and_upload () {

        sntl.shield(15, [] {
        
            // Initialize CSVary object
            CSVary csv;

            int timestamp = rtc.timestamp().toInt(); 
            String date = rtc.date("MM/DD/YY");
            String time = rtc.time("hh:mm");

            // Log to SD
            csv
                .clear()
                .setheader("SURVEYID,DEVICEID,TIMESTAMP,DATE,TIME,TEMP,RH,FLTP,RAINID,HOURID,WLEV,INT")
                .set(gb.globals.SURVEY_ID)
                .set(gb.globals.DEVICE_ID)
                .set(timestamp)
                .set(date)
                .set(time)
                .set(aht.temperature())
                .set(aht.humidity())
                .set(gb.globals.FAULTS_PRIMARY)
                .set(RAINID)
                .set(HOURID + 6)
                .set(WLEV)
                .set(RAIN_INCHES);

            //! Write current data to SD card
            sd.writeCSV(csv);
            gb.log("Readings written to SD card");

            gb.br().log("Current data point: ");
            gb.log(csv.getheader());
            gb.log(csv.getrows());

            //! Upload current data to desktop client_test
            gdc.send("data", csv.getheader() + BR + csv.getrows());
            
            /*
                ! Prepare a queue file (with current iteration's data)
                The queue file will be read and data uploaded once the network is established.
                The file gets deleted if the upload is successful. 
            */

            String currentdataqueuefile = sd.getavailablequeuefilename();

            gb.log("Wrote to queue file: " + currentdataqueuefile);
            sd.writequeuefile(currentdataqueuefile, csv);
            
        });

        // Upload to server
        send_queue_files_to_server();
        
    }

    // void diagnostics() {
    //     float wlev;
    //     wlev = eadc.getdepth(0);
    //     gb.log("Water level: " + String(wlev));
    //     bool raindetected = rain.listener();

    //     gb.br().log("Water level: " + String(wlev));
    //     if (raindetected) {
    //         gb.log("Rain detected");

    //         vst.trigger(400);
    //     }
    // }

    void nwdiagnostics () {
        
        sntl.shield(45, [] {
            
            //! Connect to network
            mcu.connect("cellular");

            sntl.kick();

            //! Connect to MQTT server
            mqtt.connect("pi", "abe-gb-mqtt");
        
        });
        
        // Turn on antifreeze monitor
        antifreeze_monitor();

        rgb.rainbow(5000);
    }

    void triggervst () {
        gb.log("Triggering auto-sampler");
        vst.trigger(400);
    }
    
    /* 
        ! Peripherals configurations and initializations
        Here, objects for the peripherals/components used are initialized and configured. This is where
        you can specify the enable pins (if used), any other pins that are being used, or whether an IO Expander is being used.

        Microcontroller configuration also includes initializing I2C, serial communications and specifying baud rates, specifying APN 
        for cellular communication or WiFi credentials if WiFi is being used.
    */
    void setup () {
        
        // Mandatory GB setup function
        gb.setup();
        
        //! Initialize GatorByte and device configurator
        gb.configure(false, "gb-irrec-test-station");
        gb.globals.ENFORCE_CONFIG = false;

        //! Configure peripherals
        ioe.configure({3, 4, 5}, 2).initialize();

        //! Configure microcontroller
        mcu.i2c().debug(Serial, 9600).serial(Serial1, 9600).configure("", "");

        //! Configure peripherals
        rgb.configure({0, 1, 2}).initialize(0.2).on("magenta");
        buzzer.configure({6}).initialize().play("...");
        
        // Detect GDC
        gdc.detect(false);
        
        //! Initialize Sentinel
        sntl.configure({false}, 9).initialize().ack(true).disablebeacon();
        
        sntl.shield(60, []() { 

            sd.configure({true, SR15, 7, SR4}).state("SKIP_CHIP_DETECT", true).initialize("quarter").readconfig().readcontrol(set_control_variables);

            //! Configure MQTT broker and connect 
            mqtt.configure("mqtt.ezbean-lab.com", 1883, gb.globals.DEVICE_ID, mqtt_message_handler, mqtt_on_connect);

            // Detect GDC
            gdc.detect(false);
            
            bl.configure({true, SR3, SR11}).initialize().persistent().on();

            // bl.send_at_command("AT+NAME" + String("GB/gb-chmd-venice")); 

            mem.configure({true, SR0}).initialize();
            aht.configure({true, SR0}).initialize();
            rtc.configure({true, SR0}).initialize();

            rtc.sync("Sep 15 2023", "16:41:00");

            vst.configure({true, SR5}).initialize();
            eadc.configure({true, SR2}).initialize();
            rain.configure({false, A2}).initialize();

            if (rain.listener()) resetvariables();
            
        });

        // //! Set Twilio APN
        // mcu.apn("super");
        
        // Detect GDC
        gdc.detect(false);

        /*
            ! Network stuff
        */
        sntl.shield(90, [] {
            
            //! Connect to network
            mcu.connect("cellular");

            sntl.kick();

            //! Connect to MQTT server
            mqtt.connect("pi", "abe-gb-mqtt");
        
        });

        
        /*
            This is a hack to eliminate the delay introduced by the DS3231 RTC.
        */
        INITSECONDS = rtc.timestamp().toDouble();

        gb.log("Init timestamp: " + String(INITSECONDS));
        gb.log("Setup complete");
        
        gb.globals.GDC_SETUP_READY = true;
        if (gb.globals.GDC_CONNECTED) {
            Serial.println("##CL-GB-READY##");
            buzzer.play("-").wait(100).play("-");
        }
    }

    bool diagflag = false;
    bool restoreflag = false;
    bool blraintrigger = false;

    void loop () {


        // return diagnostics();
        
        // MQTT update
        mqtt.update();

        //! Protection against microcontroller freeze
        antifreezepiper.pipe(ANTIFREEZE_CHECK_INTERVAL, true, [] (int counter) {
            antifreeze_monitor();
        });

        bl.listen([] (String command) {
            Serial.println("Received command: " + command);

            if (command == "help") {
                bl.print("Bluetooth command help");
                bl.print("--------------------------------------------");
                bl.print("1. reset - Resets the variables (HOURID, RAINID).");
                bl.print("2. reboot - Reboots the microcontroller.");
                bl.print("3. trigger - Trigger the autosampler.");
                bl.print("4. rain - Emulate a rain sensor tip.");
                bl.print("5. water - Get water level reading.");
                bl.print("6. data - Print SD card data.");
                bl.print("7. upload - Attempt sending " + String(sd.getqueuecount()) + " unsent data to server.");
                bl.print("6. state - Prints state variables.");
                bl.print("");

            }

            if (command == "reset") resetvariables();
            if (command == "reboot") devicereboot();
            if (command == "upload") send_queue_files_to_server();
            if (command == "trigger") triggervst();
            if (command == "beep") {
                gb.log("Milliseconds since boot: " + String(millis()));
                
                rgb.on("white");
                buzzer.play(".");
                rgb.revert();
            }
            if (command == "ping") {
                bl.print("Connection test");
                mqtt.publish("log/message", "Connection test");
            }
            if (command == "control") {
                bl.print("Control sent to server");
                send_control_variables();

            }
            if (command == "cell") {
                sntl.shield(45, [] {
                
                    //! Connect to network
                    mcu.connect("cellular");
                    
                    sntl.kick();

                    //! Connect to MQTT servver
                    mqtt.connect("pi", "abe-gb-mqtt");
                    
                });

            }
            if (command == "rain") {
                blraintrigger = true;

                rgb.on("white");
                buzzer.play("...");
                rgb.revert();
            }
            if (command == "water") {
                sntl.shield(4, [] {
                    WLEV = eadc.getdepth(0);
                    bl.print("Water level: " + String(WLEV));
                });
                
                // Turn on antifreeze monitor
                antifreeze_monitor();
            }
            if (command == "demo") {
                String data = "SURVEYID,DEVICEID,TIMESTAMP,DATE,TIME,TEMP,RH,FLTP,RAINID,HOURID,WLEV\ngb-demo-data,gb-demo-data,1687781674,26,42,15,1,12,0";
                mqtt.ack("demo_12345").publish("data/set", data);
            }
            if (command == "data") {
                bl.print("Sending data");
                String filename = "/readings/" + (gb.globals.DEVICE_ID.length() > 0 ? gb.globals.DEVICE_ID + "_" : "") + "readings.csv";
                String data = "";
                if (sd.exists(filename)) {
                    data = sd.readfile(filename);
                    bl.print(data);
                }
                else {
                    bl.print(filename + " not found.");
                }
            }
            if (command == "dataclear") {
                gb.log("Clearing SD data", false);
                String filename = "/readings/" + (gb.globals.DEVICE_ID.length() > 0 ? gb.globals.DEVICE_ID + "_" : "") + "readings.csv";
                sd.rm(filename);
                gb.log(" -> Done");
            }
            if (command == "state") {
                bl.print("Current state information:");
                bl.print("Date and time: " + String(rtc.date()) + " " + String(rtc.time()));
                bl.print("RAINID: " + String(RAINID));
                bl.print("HOURID: " + String(HOURID));
                bl.print("RAININT: " + String(RAININT));
                bl.print("Tip count: " + String(CUMULATIVE_TIP_COUNT));
                bl.print("Last tip: " + String(LAST_TIP_AT_TIMESTAMP));
                bl.print("Treatment started: " + String(TREATMENT_STARTED_AT_TIMESTAMP));
            }
            if (command == "modem") {
                bl.print("Resetting MODEM");
                MODEM.reset();
                delay(5000);

                sntl.shield(45, [] {
            
                    //! Connect to network
                    mcu.connect("cellular");

                    sntl.kick();

                    //! Connect to MQTT server
                    mqtt.connect("pi", "abe-gb-mqtt");
                
                });
                
                // Turn on antifreeze monitor
                antifreeze_monitor();
            }
        });
        
        //! Handle millis() rollover
        if (millis() > 4000000000) {
            gb.log("Resetting system to prevent millis() rollover");
            mqtt.publish("log/message", "Resetting system to prevent millis() rollover: "  + String(millis()));
            delay(5000);
            sntl.reboot();
        }
        
        // //! Prevent freezes pre-emmptively
        // if (millis() > ANTIFREEZE_REBOOT_DELAY) {
            
        //     // String laststate = mem.get(MEMLOC_LASTSTATE);
        //     gb.log("Resetting system to prevent millis() rollover/freeze");
        //     mqtt.publish("log/message", "Resetting system to prevent freeze: "  + String(millis()));
        //     delay(5000);
        //     sntl.reboot();
        // }

        
        //! Five-day anti-freeze piper
        fivedayantifreezepiper.pipe(ANTIFREEZE_REBOOT_DELAY, false, [] (int counter) {

            // String laststate = mem.get(MEMLOC_LASTSTATE);
            gb.log("Resetting system to prevent freeze");
            mqtt.publish("log/message", "Resetting system to prevent freeze: "  + String(millis()));
            delay(5000);
            sntl.reboot();
        });
        
        //! Publish ping
        pingpiper.pipe(SERVER_PING_INTERVAL, true, [] (int counter) {
            gb.log("Publishing ping count: "  + String(counter));
            mqtt.publish("log/message", "Device ping counter: "  + String(counter));
        });
        
        //! Remote variables reset/reboot listener
        resetvariablespiper.pipe(REMOTE_RESET_CHECK_INTERVAL, true, [] (int counter) {

            if (REBOOT_FLAG) {
                mqtt.publish("log/message", "Reboot request processed");
                delay(5000);
                devicereboot();
            }

            if (RESET_VARIABLES_FLAG) {
                delay(2000);
                mqtt.publish("log/message", "Variables reset completed");
                delay(2000);
                resetvariables();
            }
        });
        
        //! Breathing indicator
        breathpiper.pipe(BREATH_INTERVAL, true, [] (int counter) {
            gb.log("Milliseconds since boot: " + String(millis()));
            buzzer.play(".");
        });

        // return diagnostics();

        //! Upload control variables state to the server
        controlvariablespiper.pipe(CV_UPLOAD_INTERVAL, true, [] (int counter) {
            send_control_variables();
        });
        
        //! Upload data to server
        uploaderpiper.pipe(QUEUE_UPLOAD_INTERVAL, true, [] (int counter) {
            if (sd.getqueuecount() > 0) send_queue_files_to_server();
        });

        //! Read water level data
        wlevpiper.pipe(WLEV_SAMPLING_INTERVAL, true, [] (int counter) {

            sntl.shield(4, [] {
                WLEV = eadc.getdepth(0);
                gb.log("Water level: " + String(WLEV));
            });

            // Turn on antifreeze monitor
            antifreeze_monitor();
        });

        // Restore last action/state
        if (!restoreflag) { 
            restoreflag = true; 

            if (mem.get(MEMLOC_LASTSTATE).length() == 0) return;
            if (mem.get(MEMLOC_CUMMTIPCOUNT).length() == 0) return;

            String laststate = mem.get(MEMLOC_LASTSTATE);
            int lasttipcount = mem.get(MEMLOC_CUMMTIPCOUNT).toInt();
            int lasttipattimestamp = mem.get(MEMLOC_LASTTIPTMSTP).toInt();
            int rainid = mem.get(MEMLOC_RAINID).toInt();
            int rainintensity = mem.get(MEMLOC_RAININTENSITY).toInt();
            // int rainid = mem.get(MEMLOC_HOURID).toInt();
            int treatmentstarttimestamp = mem.get(MEMLOC_TRTSTRTTMSTP).toInt();
            
            gb.log("\nRestoring state.");
            gb.log("Last state: " + laststate); 
            gb.log("Last tip count: " + String(lasttipcount)); 
            gb.log("Last treatment started at: " + String(treatmentstarttimestamp)); 
            gb.log("Last rain ID: " + String(rainid)); 
            gb.log("Last rain intensity: " + String(rainintensity)); 
            // gb.log("Last hour ID: " + String(HOURID)); 

            
            if (laststate == "raining") {
                STATE = "raining";
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                RAIN_INCHES = rainintensity;
            }

            // Previous treatment cycle had ended
            else if (laststate == "prev-trt-end") {
                STATE = "raining|prev-trt-end";
                RAINID = rainid;
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                RAIN_INCHES = rainintensity;
                
                gb.log("Restoring state to after the end of previous treatment cycle. Rain ID: " + String(RAINID));
            }

            // New treatment cycle had bugun
            else if (laststate == "new-trt-begin") {
                STATE = "raining|prev-trt-end|new-trt-begin";
                RAINID = rainid;
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                TREATMENT_STARTED_AT_TIMESTAMP = treatmentstarttimestamp;
                RAIN_INCHES = rainintensity;

                gb.log("Restoring ongoing treatment cycle. Rain ID: " + String(RAINID));
            }

            // First sample of the new treatment cycle was already taken (6-hr sample)
            else if (laststate == "0-hr-sample") {
                STATE = "raining|prev-trt-end|new-trt-begin|0-hr-sample";
                RAINID = rainid;
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                TREATMENT_STARTED_AT_TIMESTAMP = treatmentstarttimestamp;
                HOURID = 0;
                RAIN_INCHES = rainintensity;

                gb.log("Restoring state. 0-hour sample already taken.");
            }

            // Second sample of the new treatment cycle was already taken (9-hr sample)
            else if (laststate == "3-hr-sample") {
                STATE = "raining|prev-trt-end|new-trt-begin|0-hr-sample|3-hr-sample";
                RAINID = rainid;
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                TREATMENT_STARTED_AT_TIMESTAMP = treatmentstarttimestamp;
                HOURID = 3;
                RAIN_INCHES = rainintensity;

                gb.log("Restoring state. 3-hour sample already taken.");
            }

            // Third sample of the new treatment cycle was already taken (12-hr sample)
            else if (laststate == "6-hr-sample") {
                STATE = "raining|prev-trt-end|new-trt-begin|0-hr-sample|3-hr-sample|6-hr-sample";
                RAINID = rainid;
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                TREATMENT_STARTED_AT_TIMESTAMP = treatmentstarttimestamp;
                HOURID = 6;
                RAIN_INCHES = rainintensity;

                gb.log("Restoring state. 6-hour sample already taken.");
            }

            // Fourth sample of the new treatment cycle was already taken (15-hr sample)
            else if (laststate == "9-hr-sample") {
                STATE = "raining|prev-trt-end|new-trt-begin|0-hr-sample|3-hr-sample|6-hr-sample|9-hr-sample";
                RAINID = rainid;
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                TREATMENT_STARTED_AT_TIMESTAMP = treatmentstarttimestamp;
                HOURID = 9;
                RAIN_INCHES = rainintensity;

                gb.log("Restoring state. 9-hour sample already taken.");
            }

            // Fifth sample of the new treatment cycle was already taken (18-hr sample)
            else if (laststate == "12-hr-sample") {
                STATE = "dry";
                RAINID = rainid;
                CUMULATIVE_TIP_COUNT = lasttipcount;
                LAST_TIP_AT_TIMESTAMP = lasttipattimestamp;
                TREATMENT_STARTED_AT_TIMESTAMP = treatmentstarttimestamp;
                HOURID = 12;
                RAIN_INCHES = rainintensity;

                gb.log("Restoring state. 12-hour sample already taken. Waiting for the end of the current treatment cycle.");
            }

            gb.br().log("Ready to receive Bluetooth commands.");
            gb.br();
        }

        
        //! Upload state to the server
        statepiper.pipe(STATE_UPLOAD_INTERVAL, true, [] (int counter) {
            send_state();
        });

        /*
            ! Check the current state of the system and take actions accordingly
            Possible states:
                1. IDLE - No rain in the last 12 hours
                2. ACTIVE - Rain was detected within the last 12 hours

            State variables:
                1. RAINID - The ID of current rain event and corresponding samples (0, 1, 2, 3, ...)
                2. TIME - Time elapsed since the current rain event was first detected (in hours)
                3. RAININT - Rain intesity for the current rain event (in inches)

        */
       
        // Check if a rain is happening right now (check if the bucket has tipped)
        bool raindetected = rain.listener() || blraintrigger;
        if (blraintrigger) blraintrigger = false;
        // bool raindetected = false;

        if (raindetected) {

            gb.br().log("Current state: " + STATE);
            
            RAIN_INCHES += 1; 
            mem.write(MEMLOC_RAININTENSITY, String(RAIN_INCHES));

            gb.br().log("Rain detected.");
        }

        /*
            ! If rain detected and a new rain event has not started yet

            This contains of following scenarios/states
                1. Blank slate 
                    The GatorBit booted for the first time
                2. Previous treatment cycle hasn't ended yet
                3. Bucket tips after a timeout delay
                    This resets the tip counter
        */
        if (raindetected && !STATE.contains("new-trt-begin")) {

            /*
                This state includes
                    1. Before the old treatment hasn't ended yet (3 tips haven't occured yet)
                    2. Old treatment has ended. New treatment hasn't begun yet (tip count is between 3 and 10)
            */

            int now = INITSECONDS + (millis() / 1000);

            /*
                - Detect if this bucket tip marks the first tip of the rain event
            */
            if 
            (
                !STATE.contains("raining")
            )  { 
            
                FIRST_TIP_AT_TIMESTAMP = now;
                LAST_TIP_AT_TIMESTAMP = now;
                STATE = "raining";
                CUMULATIVE_TIP_COUNT = 1;

                mem.write(MEMLOC_LASTSTATE, STATE);
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));
                
                gb.br().log("New rain event.");
                gb.log("Cumulative tip count: " + String(CUMULATIVE_TIP_COUNT));
                gb.log("Rain intensity: " + String(RAIN_INCHES));
            }
            
            /*
                - If this bucket tip is a continuation of the rain event
            */
            else if 
            (
                STATE.contains("raining") && 
                (now - LAST_TIP_AT_TIMESTAMP < INTER_TIP_TIMEOUT)
            ) { 
            
                LAST_TIP_AT_TIMESTAMP = now;
                CUMULATIVE_TIP_COUNT += 1;
                
                mem.write(MEMLOC_LASTSTATE, String(STATE.contains("prev-trt-end") ? "prev-trt-end" : "raining"));
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));
                
                gb.log("Continuing rain event.");
                gb.log("Cumulative tip count: " + String(CUMULATIVE_TIP_COUNT));
                gb.log("Rain intensity: " + String(RAIN_INCHES));
            }
            
            /*
                - If this bucket tip happens after the time out
            */
            else if 
            (
                STATE.contains("raining") &&
                (now - LAST_TIP_AT_TIMESTAMP >= INTER_TIP_TIMEOUT)
            ) {

                // Reset tip count to 0 and increment to 1
                FIRST_TIP_AT_TIMESTAMP = now;
                LAST_TIP_AT_TIMESTAMP = now;
                STATE = "raining" + String(STATE.contains("prev-trt-end") ? "|prev-trt-end" : "");
                CUMULATIVE_TIP_COUNT = 1;

                mem.write(MEMLOC_LASTSTATE, String(STATE.contains("prev-trt-end") ? "prev-trt-end" : ""));
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));
                
                gb.log("Tip bucket timeout. New rain event.");
                gb.log("Cumulative tip count: " + String(CUMULATIVE_TIP_COUNT)); 
                gb.log("Rain intensity: " + String(RAIN_INCHES));
            }

            // ------------------------------------------------------------------------------------------------------------

            /*
                Check if the tip count is more than END_TIP_CONT_THRESHOLD
            */
            if 
            (
                !STATE.contains("prev-trt-end") &&
                CUMULATIVE_TIP_COUNT >= END_TIP_CONT_THRESHOLD
            ) {

                gb.log("Previous treatment cycle has ended.");
                gb.log("Taking sample t = inf hr");
                STATE += "|prev-trt-end";

                if (mem.get(MEMLOC_RAINID) == "") mem.write(MEMLOC_RAINID, "0");
                RAINID = mem.get(MEMLOC_RAINID).toInt();
                gb.log("All samples taken for Rain ID: " + String(RAINID) + ". Pending pickup.");

                // Save state to EEPROM
                mem.write(MEMLOC_LASTSTATE, "prev-trt-end");
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));
                mem.write(MEMLOC_RAININTENSITY, String(RAIN_INCHES));

                /*
                    TODO: Write state to EEPROM
                    TODO: Get RTC timestamp
                    TODO: Send message to server
                    TODO: Write to SD card
                */

                HOURID = 94;
                triggervst();
                write_data_to_sd_and_upload();
                gb.log("Finished taking sample and reporting data");
                mcu.watchdog("disable");
            }

            /*
                Check if the tip count is more than MIN_TIP_CONT_THRESHOLD
            */
            if (!STATE.contains("new-trt-begin") && CUMULATIVE_TIP_COUNT >= MIN_TIP_CONT_THRESHOLD) {
                STATE += "|new-trt-begin";
                CUMULATIVE_TIP_COUNT = 0;

                // TREATMENT_STARTED_AT_TIMESTAMP = millis() / 1000;
                // TREATMENT_STARTED_AT_TIMESTAMP = rtc.timestamp().toInt();
                TREATMENT_STARTED_AT_TIMESTAMP = INITSECONDS + (millis() / 1000);

                // Save state to EEPROM
                if (mem.get(MEMLOC_RAINID) == "") mem.write(MEMLOC_RAINID, "0");
                RAINID = mem.get(MEMLOC_RAINID).toInt() + 1;
                mem.write(MEMLOC_RAINID, String(RAINID));

                mem.write(MEMLOC_LASTSTATE, "new-trt-begin");
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_TRTSTRTTMSTP, String(TREATMENT_STARTED_AT_TIMESTAMP));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));

                gb.log("Starting new treatment cycle. Rain ID: " + String(RAINID));
            }
        }

        /*
            ! If the bucket tips after a new treatment cycle bagan

            This contains of following scenarios/states
                1. Bucket tips within a timeout
                    This will reset the 6-hr timer
        */
        else if (raindetected && STATE.contains("new-trt-begin") && !STATE.contains("-hr-sample")) {
            
            gb.log("Continuing treatment cycle.");
            gb.log("A tip was detected. Resetting 6 hr timer to 0.");
            gb.log("Rain intensity: " + String(RAIN_INCHES));

            // Reset treatment start timestamp
            // TREATMENT_STARTED_AT_TIMESTAMP = millis() / 1000;
                // TREATMENT_STARTED_AT_TIMESTAMP = rtc.timestamp().toInt();
                TREATMENT_STARTED_AT_TIMESTAMP = INITSECONDS + (millis() / 1000);

            mem.write(MEMLOC_TRTSTRTTMSTP, String(TREATMENT_STARTED_AT_TIMESTAMP));
            mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));
        }

        /*
            ! If no rain detected after a new treatment cycle bagan and it's time to take samples

            This contains of following scenarios/states
                1. 3-hr samples on a timer
                    a. 0-hr
                    b. 3-hr
                    c. 6-hr
                    d. 9-hr
                    e. 12-hr
        */
        else if (!raindetected && STATE.contains("new-trt-begin")) {
            
            // gb.log("Undergoing the new treatment cycle");

            /*
                ! Known issue - Fixed
                The DS3231 library adds a delay that prevents rain pulse detection most of the time.
                A solution would be to use millis() function, but that will prevent resetting the state after an unexpected system reset.
            */
            // int now = rtc.timestamp().toInt();
            int now = INITSECONDS + (millis() / 1000);

            // gb.log("Initialized seconds: " + String(INITSECONDS));
            // gb.log("Current timestamp: " + String(now));
            // gb.log("Treatment start timestamp: " + String(TREATMENT_STARTED_AT_TIMESTAMP));
            // gb.log("Seconds since: " + String((now - TREATMENT_STARTED_AT_TIMESTAMP)));
            // gb.log("Hours since: " + String((now - TREATMENT_STARTED_AT_TIMESTAMP) / 3600));
            // gb.br();

            HOURID = (now - TREATMENT_STARTED_AT_TIMESTAMP) / 3600;
            LAST_TIP_AT_TIMESTAMP = now;
            // HOURID = (now - TREATMENT_STARTED_AT_TIMESTAMP);
            // mem.write(MEMLOC_TRTSTRTTMSTP, String(TREATMENT_STARTED_AT_TIMESTAMP));
            
            // gb.log(HOURID / 3600);
            // gb.log(HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 1);
            // gb.log("");

            if (
                // HOURID < (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 1) && 
                HOURID * 60 * 60 * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 0) && 
                // HOURID * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 0) && 
                !STATE.contains("0-hr-sample")
            ) {
                gb.log("Water homogenization complete");
                gb.log("Taking sample t = 0 hr");
                STATE += "|0-hr-sample";
                
                // Save state to EEPROM
                mem.write(MEMLOC_LASTSTATE, "0-hr-sample");
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));

                HOURID = 0;
                triggervst();
                write_data_to_sd_and_upload();
                gb.log("Finished taking sample and reporting data");
                mcu.watchdog("disable");
            }
            
            else if (
                // HOURID < (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 2) && 
                HOURID * 60 * 60 * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 1) && 
                // HOURID * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 1) && 
                !STATE.contains("3-hr-sample")
            ) {
                gb.log("Taking sample t = 3 hr");
                STATE += "|3-hr-sample";
                
                // Save state to EEPROM
                mem.write(MEMLOC_LASTSTATE, "3-hr-sample");
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));

                HOURID = 3;
                triggervst();
                write_data_to_sd_and_upload();
                gb.log("Finished taking sample and reporting data");
                mcu.watchdog("disable");
            }

            else if (
                // HOURID < (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 3) && 
                HOURID * 60 * 60 * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 2) && 
                // HOURID * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 2) && 
                !STATE.contains("6-hr-sample")
            ) {
                gb.log("Taking sample t = 6 hr");
                STATE += "|6-hr-sample";
                
                // Save state to EEPROM
                mem.write(MEMLOC_LASTSTATE, "6-hr-sample");
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));

                HOURID = 6;
                triggervst();
                write_data_to_sd_and_upload();
                gb.log("Finished taking sample and reporting data");
                mcu.watchdog("disable");
            }

            else if (
                // HOURID < (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 4) && 
                HOURID * 60 * 60 * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 3) && 
                // HOURID * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 3) && 
                !STATE.contains("9-hr-sample")
            ) {
                gb.log("Taking sample t = 9 hr");
                STATE += "|9-hr-sample";

                // Save state to EEPROM
                mem.write(MEMLOC_LASTSTATE, "9-hr-sample");
                mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));

                HOURID = 9;
                triggervst();
                write_data_to_sd_and_upload();
                gb.log("Finished taking sample and reporting data");
                mcu.watchdog("disable");
            }
            
            else if (
                HOURID * 60 * 60 * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 4) && 
                // HOURID * 1000 >= (HOMOGENIZATION_DELAY + INTER_SAMPLE_DURATION * 4) && 
                !STATE.contains("12-hr-sample")
            ) {
                gb.log("Taking sample t = 12 hr");
                STATE += "|12-hr-sample";

                // Reset state
                STATE = "dry";
                
                // Save state to EEPROM
                mem.write(MEMLOC_LASTSTATE, "dry");
                mem.write(MEMLOC_CUMMTIPCOUNT, String(0));
                mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));

                HOURID = 12;
                triggervst();
                write_data_to_sd_and_upload();
                gb.log("Finished taking sample and reporting data");
                mcu.watchdog("disable");
            }
            
        }

        else if (raindetected && STATE.contains("new-trt-begin") && STATE.contains("-hr-sample")) {
            
            int now = INITSECONDS + (millis() / 1000);
            // int now = millis(); 

            if (!STATE.contains("new-trt-rain")) STATE += "new-trt-rain";
            CUMULATIVE_TIP_COUNT += 1;
            LAST_TIP_AT_TIMESTAMP = now;
            gb.br().log("Mid-treatment cycle rain detected.");
            gb.log("Cumulative tip count: " + String(CUMULATIVE_TIP_COUNT));
            gb.log("Rain intensity: " + String(RAIN_INCHES));

            if (
                    CUMULATIVE_TIP_COUNT >= END_TIP_CONT_THRESHOLD
                ) {

                    gb.log("The treatment cycle has ended.");
                    gb.log("Taking sample t = inf hr");
                    
                    STATE = "raining|prev-trt-end";
                    RAIN_INCHES = 0;

                    gb.log("Some samples taken for Rain ID: " + String(RAINID) + ". Pending pickup.");
                
                    // Save state to EEPROM
                    mem.write(MEMLOC_LASTSTATE, "prev-trt-end");
                    mem.write(MEMLOC_CUMMTIPCOUNT, String(CUMULATIVE_TIP_COUNT));
                    mem.write(MEMLOC_LASTTIPTMSTP, String(LAST_TIP_AT_TIMESTAMP));
                    mem.write(RAIN_INCHES, String(RAIN_INCHES));
                    
                    /*
                        TODO: Write state to EEPROM
                        TODO: Send message to server
                        TODO: Write to SD card
                    */
                   
                    HOURID = 93;
                    triggervst();
                    write_data_to_sd_and_upload();
                    gb.log("Finished taking sample and reporting data");
                    mcu.watchdog("disable");
                }
        }
    }

    int count = 0;
    void breathe() {
        gb.log("Breathing counter: " + String(count++));
        
        mqtt.update();
        
        gb.breathe();
    }

#endif