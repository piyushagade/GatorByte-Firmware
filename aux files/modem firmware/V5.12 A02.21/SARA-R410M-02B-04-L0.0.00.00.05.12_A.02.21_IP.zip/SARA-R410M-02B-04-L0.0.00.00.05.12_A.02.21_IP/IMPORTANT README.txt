README

SARA-R410M-02B-04-P1-L0000000512A0221-000K00-correct MD5
MD5: c60f954ab0dd69af1a2c89d7ea92b6c6

Close QPST and all other Qualcomm Tools before Flashing with EasyFlash 
Use EasyFlash 13.03.1.2
-DO NOT use an older version

